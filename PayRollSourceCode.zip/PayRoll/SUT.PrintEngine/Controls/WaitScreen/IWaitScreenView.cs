﻿using SUT.PrintEngine.Views;

namespace SUT.PrintEngine.Controls.WaitScreen
{
    public interface IWaitScreenView:IView
    {
    }
}
