
USE [PayrollDB];

delete from PayrollItems where ParentPayrollItemId is not null

delete from PayrollItems