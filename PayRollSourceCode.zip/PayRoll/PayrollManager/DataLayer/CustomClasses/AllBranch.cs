﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace PayrollManager.DataLayer
//{
//    public partial class AllBranch:Branch
//    {
//        public AllBranch()
//        {
            
//        }

//        List<Employee> employees = new List<Employee>();
//        public new List<Employee> Employees
//        {
//            get
//            {
//                return employees;
//            }
//            set
//            {
//                employees = value;
//            }
//        }

//        public new List<DataLayer.PayrollJob> PayrollJobs { get; set; }

//        public int TotalEmployees
//        {
//            get
//            {
//                return employees.Count;
//            }
//        }


//    }
//}
