﻿namespace ExtendedGrid.Classes
{
    class RowSummariesHelper
    {
      

        public static string CurrentColumn { get; set; }
    }
}
